class Card {
  constructor(rank, suit) {
    this.rank = rank;
    this.suit = suit;
  }

  getValue() {
    if (this.rank === "A") return 11;
    if (["K", "Q", "J"].includes(this.rank)) return 10;
    return Number(this.rank);
  }

  isRed() {
    return this.suit === "H" || this.suit === "D";
  }

  suitSymbol() {
    const symbols = {
      H: "♥",
      S: "♠",
      D: "♦",
      C: "♣"
    };
    return symbols[this.suit];
  }
}

class Blackjack {
  constructor() {
    this.deck = [];
    this.playerHand = [];
    this.dealerHand = [];
    this.resetCards();
  }

  resetCards() {
    this.deck = [];
    this.playerHand = [];
    this.dealerHand = [];
    this.newDeck();
    this.shuffleDeck();
  }

  newDeck() {
    const ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];
    const suits = ["H", "S", "D", "C"];

    for (const suit of suits) {
      for (const rank of ranks) {
        this.deck.push(new Card(rank, suit));
      }
    }
  }

  shuffleDeck() {
    for (let i = this.deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [this.deck[i], this.deck[j]] = [this.deck[j], this.deck[i]];
    }
  }

  dealCard() {
    if (this.deck.length === 0) {
      this.resetCards();
    }
    return this.deck.shift();
  }

  dealStartingHands() {
    this.playerHand.push(this.dealCard());
    this.dealerHand.push(this.dealCard());
    this.playerHand.push(this.dealCard());
    this.dealerHand.push(this.dealCard());
  }

  addCardToPlayer() {
    this.playerHand.push(this.dealCard());
  }

  addCardToDealer() {
    this.dealerHand.push(this.dealCard());
  }

  calculateHandValue(hand) {
    let total = 0;
    let aces = 0;

    for (const card of hand) {
      total += card.getValue();
      if (card.rank === "A") aces += 1;
    }

    while (total > 21 && aces > 0) {
      total -= 10;
      aces -= 1;
    }

    return total;
  }

  getPlayerTotal() {
    return this.calculateHandValue(this.playerHand);
  }

  getDealerTotal() {
    return this.calculateHandValue(this.dealerHand);
  }
}

class Game {
  constructor() {
    this.blackjack = new Blackjack();
    this.message = "";
    this.roundOver = true;
    this.dealerTurn = false;
    this.uOweMoney = false;
    this.credits = 100;
    this.bet = 10;
    this.currentBet = 10;
    this.wins = 0;
    this.losses = 0;
    this.ties = 0;
    this.roundsPlayed = 0;
    this.newRound();
  }

  newRound() {
    if (this.uOweMoney) {
      this.message = "Account frozen. You are out of credits.";
      return;
    }

    if (!this.roundOver) {
      this.credits -= this.currentBet;
      this.losses += 1;
      this.roundsPlayed += 1;
      this.checkAccount();

      if (this.uOweMoney) {
        this.message = "You quit the round and lost your bet. Account frozen.";
        this.roundOver = true;
        return;
      }
    }

    if (this.bet > this.credits) {
      this.bet = this.credits;
    }

    if (this.credits <= 0) {
      this.credits = 0;
      this.uOweMoney = true;
      this.message = "Account frozen. You are out of credits.";
      this.roundOver = true;
      return;
    }

    this.currentBet = this.bet;
    this.blackjack.resetCards();
    this.blackjack.dealStartingHands();
    this.bet = 10;

    this.message = `Bet: ${this.currentBet} credits. Hit or Stand?`;
    this.roundOver = false;
    this.dealerTurn = false;
  }

  hit() {
    if (this.roundOver || this.dealerTurn) return;

    this.blackjack.addCardToPlayer();

    if (this.blackjack.getPlayerTotal() > 21) {
      this.credits -= this.currentBet;
      this.losses += 1;
      this.roundsPlayed += 1;
      this.checkAccount();

      if (this.uOweMoney) {
        this.message = "You got busted. Dealer wins. You lost everything.";
      } else {
        this.message = `You got busted. Dealer wins. -${this.currentBet} credits.`;
      }

      this.roundOver = true;
    } else {
      this.message = "Hit or Stand?";
    }
  }

  stand() {
    if (this.roundOver) return;

    this.dealerTurn = true;

    while (this.blackjack.getDealerTotal() < 17) {
      this.blackjack.addCardToDealer();
    }

    this.decideWinner();
  }

  decideWinner() {
    const playerTotal = this.blackjack.getPlayerTotal();
    const dealerTotal = this.blackjack.getDealerTotal();

    if (dealerTotal > 21) {
      this.credits += this.currentBet;
      this.wins += 1;
      this.roundsPlayed += 1;
      this.message = `Dealer busted. You win! +${this.currentBet} credits.`;
    } else if (playerTotal > dealerTotal) {
      this.credits += this.currentBet;
      this.wins += 1;
      this.roundsPlayed += 1;
      this.message = `You win! +${this.currentBet} credits.`;
    } else if (dealerTotal > playerTotal) {
      this.credits -= this.currentBet;
      this.losses += 1;
      this.roundsPlayed += 1;
      this.checkAccount();

      if (this.uOweMoney) {
        this.message = "Dealer wins. You lost all your money.";
      } else {
        this.message = `Dealer wins. -${this.currentBet} credits.`;
      }
    } else {
      this.ties += 1;
      this.roundsPlayed += 1;
      this.message = "Push. It is a tie. No credits lost.";
    }

    this.roundOver = true;
  }

  checkAccount() {
    if (this.credits <= 0) {
      this.credits = 0;
      this.uOweMoney = true;
    }

    if (this.bet > this.credits && this.credits > 0) {
      this.bet = this.credits;
    }
  }

  increaseBet() {
    if (this.uOweMoney) {
      this.message = "Account frozen. You are out of credits.";
      return;
    }

    if (!this.roundOver) {
      this.message = "Finish the round before changing your bet.";
      return;
    }

    if (this.bet + 10 <= this.credits) {
      this.bet += 10;
      this.currentBet = this.bet;
      this.message = `Bet increased to ${this.bet} credits.`;
    } else {
      this.message = "You cannot bet more than you have.";
    }
  }
}

const game = new Game();

const dealerHandElement = document.getElementById("dealer-hand");
const playerHandElement = document.getElementById("player-hand");
const dealerTotalElement = document.getElementById("dealer-total");
const playerTotalElement = document.getElementById("player-total");
const messageElement = document.getElementById("message");

const creditsElement = document.getElementById("credits");
const currentBetElement = document.getElementById("current-bet");
const winsElement = document.getElementById("wins");
const lossesElement = document.getElementById("losses");
const tiesElement = document.getElementById("ties");
const roundsElement = document.getElementById("rounds");
const statusElement = document.getElementById("status");

const hitButton = document.getElementById("hit-button");
const standButton = document.getElementById("stand-button");
const newRoundButton = document.getElementById("new-round-button");
const betButton = document.getElementById("bet-button");

function createCardElement(card, hidden = false) {
  const cardElement = document.createElement("div");

  if (hidden) {
    cardElement.className = "card back";
    cardElement.textContent = "?";
    return cardElement;
  }

  cardElement.className = card.isRed() ? "card red" : "card";

  const label = `${card.rank}${card.suitSymbol()}`;

  cardElement.innerHTML = `
    <span class="top">${label}</span>
    <span class="center">${card.suitSymbol()}</span>
    <span class="bottom">${label}</span>
  `;

  return cardElement;
}

function renderHand(element, hand, hideDealerFirstCard = false) {
  element.innerHTML = "";

  hand.forEach((card, index) => {
    const hidden = hideDealerFirstCard && index === 0;
    element.appendChild(createCardElement(card, hidden));
  });
}

function render() {
  const hideDealerFirstCard = !game.dealerTurn && !game.roundOver;

  renderHand(dealerHandElement, game.blackjack.dealerHand, hideDealerFirstCard);
  renderHand(playerHandElement, game.blackjack.playerHand);

  if (game.dealerTurn || game.roundOver) {
    dealerTotalElement.textContent = `Dealer Total: ${game.blackjack.getDealerTotal()}`;
  } else {
    dealerTotalElement.textContent = "Dealer Total: ?";
  }

  playerTotalElement.textContent = `Player Total: ${game.blackjack.getPlayerTotal()}`;
  messageElement.textContent = game.message;

  creditsElement.textContent = game.credits;
  currentBetElement.textContent = game.currentBet;
  winsElement.textContent = game.wins;
  lossesElement.textContent = game.losses;
  tiesElement.textContent = game.ties;
  roundsElement.textContent = game.roundsPlayed;
  statusElement.textContent = game.uOweMoney ? "Frozen" : "Active";

  hitButton.disabled = game.roundOver || game.dealerTurn || game.uOweMoney;
  standButton.disabled = game.roundOver || game.uOweMoney;
  betButton.disabled = !game.roundOver || game.uOweMoney;
}

hitButton.addEventListener("click", () => {
  game.hit();
  render();
});

standButton.addEventListener("click", () => {
  game.stand();
  render();
});

newRoundButton.addEventListener("click", () => {
  game.newRound();
  render();
});

betButton.addEventListener("click", () => {
  game.increaseBet();
  render();
});

render();
