---
layout: page
title: Blackjack Game
permalink: /blackjack/
---

# Blackjack Game

I made this blackjack game for my computer science project. The goal is to get closer to 21 than the dealer without going over.

<iframe
  src="{{ '/assets/blackjack/index.html' | relative_url }}"
  width="100%"
  height="760"
  style="border: 0; border-radius: 12px; overflow: hidden;"
  loading="lazy">
</iframe>
